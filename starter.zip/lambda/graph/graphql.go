package graph

import (
    "github.com/labstack/echo/v4"
)


func Set(e *echo.Echo) {


}


#!/bin/sh

./lambda-app & nohup >> lambda.log

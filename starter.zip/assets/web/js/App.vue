<template>
    <div>
        <h1>Vue App - Hot reloading</h1>
    </div>
</template>

<script>
export default {
    data() {
        return {
        }
    }
}
</script>

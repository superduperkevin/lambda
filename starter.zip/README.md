# Lambda Platform basic example
1. `go mod download` 
2. `create your Database and Set database (host, username and password) in .env`
3. `go run main.go`
   You are ready :)
